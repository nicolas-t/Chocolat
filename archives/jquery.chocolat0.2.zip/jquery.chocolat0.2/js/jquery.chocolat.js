// Inspired by the lightbox plugin adapted to jquery by Leandro Vieira Pinho (http://leandrovieira.com)
// Nicolas Turlais
// Licensed under CCAttribution-ShareAlike
// V0.2
(function($) {
	images = new Array();
	$.fn.Chocolat = function(settings) {
		settings = $.extend({
			modeText:					false,
			linksContainer:				'Choco_links_container',	// must be an <ul> ID , #					
			overlayOpacity:				0.9,
			overlayCouleur:				'#fff',
			vitesseApparitionOverlay:	500,
			vitesseApparitionImage:		500,
			vitesseDisparitionImage:	500,
			vache:						true,						//active(true) ou non(false) la fermeture lorsque l'on clique sur le fond.
			separateur1:				' | ',						//separe le titre la serie de la position de l'image au sein de la s�rie ...
			separateur2:				'/',						//s�pare l'image actuelle sur le nombre d'image total dans la s�rie...
			gaucheImg:					'images/gauche.gif',		//chemin vers l'image pour aller vers la gauche
			droiteImg:					'images/droite.gif',		//chemin vers l'image pour aller vers la droite
			fermerImg:					'images/close.gif',			//chemin vers l'image pour fermer chocolat
			imageActuelle:				0,							//ici devient l'image de d�part...
			serie:						0,
			nomSerie:					0,
			derniereImage:				0
		},settings);
		this.each(function(index){
			settings.serie = images.length;
			settings.nomSerie = $(this).attr('title');
			images[settings.serie] = new Array();
			if($(this).get(0).tagName == 'A'){e = $(this);}// si l'appel est fait sur les liens
			else{e = $(this).children();}// sinon (sur une div)
			e.each(function(index) {
				images[settings.serie][index] = new Array();
				images[settings.serie][index]['adresse'] = $(this).attr('href');
				images[settings.serie][index]['legende'] = $(this).attr('title');
				if(!settings.modeText){
					$(this).unbind('click').bind('click', {id: settings.serie, nom : settings.nomSerie, i : index}, _initialise);
				}
			})
			if(settings.modeText){
				if($('#'+settings.linksContainer).size() == 0){
					$(this).before('<ul id="'+settings.linksContainer+'"></ul>');
				}
				$('#'+settings.linksContainer).append('<li><a href="#" id="Choco_numserie_'+settings.serie+'" class="Choco_link">'+settings.nomSerie+'</a></li>');
				$(this).remove();
			return $('#Choco_numserie_'+settings.serie).unbind('click').bind('click', {id: settings.serie, nom : settings.nomSerie, i : settings.imageActuelle}, _initialise);
			}
			});
	
		function _initialise(event) {
			settings.imageActuelle = event.data.i;
			settings.serie = event.data.id;
			settings.nomSerie = event.data.nom;
			afficherChocolat(settings.serie); //recupere numserie dans id .
			return false;
		}
		function _interface(){
			//html
			$('body').append('<div id="Choco_overlay"></div><div id="Choco_content"><div id="Choco_close"></div><div id="Choco_container_photo"></div><div id="Choco_container_description"><span id="Choco_container_titre"></span><span id="Choco_container_via"></span></div><div id="Choco_aller_gauche" class="Choco_fleches"></div><div id="Choco_aller_droite" class="Choco_fleches"></div></div>');	
			$('#Choco_aller_gauche').css('background-image', 'url('+settings.gaucheImg+')');  
			$('#Choco_aller_droite').css('background-image', 'url('+settings.droiteImg+')');  
			$('#Choco_close').css('background-image', 'url('+settings.fermerImg+')');  
			//events
			$(document).unbind().bind('keypress', function(e){
				switch(e.keyCode){
					case 37:
						changePageChocolat(-1);
						break;
					case 39:
						changePageChocolat(1);
						break;
					case 27:
						close();
						break;
				};
			});
			if(settings.vache){
				$('#Choco_overlay').click(function(){
					close();
					return false;
				});
			}
			$('#Choco_aller_gauche').unbind().bind('click', function(){
				changePageChocolat(-1);
				return false;
			});
			$('#Choco_aller_droite').unbind().bind('click', function(){
				changePageChocolat(1);
				return false;
			});
			$('#Choco_close').unbind().bind('click', function(){
				close();
				return false;
			});
			
			$(window).resize(function() {
				load(settings.imageActuelle,true);//load (image, resize)
			});
		}
		function afficherChocolat(numero_serie){	
			_interface();
			settings.serie = numero_serie;
			settings.derniereImage = images[settings.serie].length - 1;
			load(settings.imageActuelle);
			$('#Choco_overlay').height($(document).height()).css({'background-color' : settings.overlayCouleur, 'opacity' : settings.overlayOpacity}).fadeIn(settings.vitesseApparitionOverlay);
			$('#Choco_content').css({'display' : 'block'});
		}
		
		function gestionFlechesChocolat(quoi){
			montrer = true;
			if(quoi == 'Choco_aller_droite' && settings.imageActuelle == settings.derniereImage){
				montrer = false;
			}
			else if(quoi == 'Choco_aller_gauche' && settings.imageActuelle == 0){
				montrer = false;
			}
			if(montrer){
				$('#'+quoi).css({'display':'block'});
			}
		}
		function preload(){
			if(settings.imageActuelle !== settings.derniereImage){
				i = new Image;
				z = settings.imageActuelle + 1;
				i.src = images[settings.serie][z]['adresse'];
			}
		}
		function load(y,resize){
			resize = resize || false;		
			settings.imageActuelle = y;
			var imgPreloader = new Image();
			imgPreloader.src = images[settings.serie][settings.imageActuelle]['adresse'];

			$('#Choco_container_photo').html('<img id=\"Choco_grandeImage\" src=\"\" />');

			imgPreloader.onload = function(){
				$('#Choco_grandeImage').attr('src',images[settings.serie][settings.imageActuelle]['adresse']);
				var ajustees = ajuster_taille(imgPreloader.height,imgPreloader.width);
				var largeur_image = ajustees['largeur'];
				var hauteur_image = ajustees['hauteur'];
				ChoColat(hauteur_image,largeur_image,resize);
				imgPreloader.onload=function(){};
			};
			imgPreloader.src = images[settings.serie][settings.imageActuelle]['adresse'];
			preload();
			majDesc();
		}
		function changePageChocolat(signe){
			if(settings.imageActuelle == 0 && signe == -1)
			{
				return false;
			}
			else if(settings.imageActuelle == settings.derniereImage && signe == 1){
				return false;
			}
			else{
				$('#Choco_container_description').fadeOut(settings.vitesseDisparitionImage);
				$('#Choco_content').fadeOut(settings.vitesseDisparitionImage,function (){
					$('#Choco_content').css({'display' : 'block'});
					$('#Choco_container_photo').html('');
					load(settings.imageActuelle + parseInt(signe));
				});
			}
		}
		function majDesc(){
			var actuelle = settings.imageActuelle + 1;
			var finale = settings.derniereImage + 1;
			$('#Choco_container_titre').html(images[settings.serie][settings.imageActuelle]['legende']);
			$('#Choco_container_via').html(settings.nomSerie+settings.separateur1+actuelle +settings.separateur2+finale);
		}

		function ChoColat(hauteur_image,largeur_image,resize){
		$('#Choco_container_photo').css({'display' : 'block'});
		$('.Choco_fleches').fadeOut(settings.vitesseDisparitionImage, function(){//(-100)
			gestionFlechesChocolat($(this).attr('id'));
		});
			if(resize){
				// stop sert � eviter les saccades lorsque l'on redimentsionne la fenetre. bizarrement, stop induit un overflow hidden, d'o� la suite.
				$('#Choco_content').stop(true,false).css({'overflow':'visible'})
			}
			$('#Choco_content').animate({
				'height' : hauteur_image,
				'width' : largeur_image,
				'marginLeft' : -largeur_image/2,
				'marginTop' : -(hauteur_image+50)/2
			},400, 'swing', function(){
					$('#Choco_container_description').fadeIn(settings.vitesseApparitionImage);
					$('#Choco_grandeImage').css('marginTop',-20).height(hauteur_image).width(largeur_image).fadeIn(settings.vitesseApparitionImage);
					$('#Choco_aller_gauche, #Choco_aller_droite').css('top',-hauteur_image-30);
			});
		}
		function ajuster_taille(himg,limg){
			var lblock = limg + 200;
			var hblock = himg + 65;
			
			var k = limg/himg;
			var kk = himg/limg;
			
			var windowWidth = $(window).width();
			var windowHeight = $(window).height();

			notFitting = true;
				while (notFitting){
				var lblock = limg + 200;
				var hblock = himg + 65;
					if(lblock > windowWidth){
						limg = (windowWidth - 250);
						himg = kk * limg;
					}else if(hblock > windowHeight){
						himg = (windowHeight - 105);
						limg = k * himg;
					}else{
						notFitting = false;
					};
				};
			return {
				largeur:limg,
				hauteur:himg
			};

		}
		function close(){
			$('#Choco_overlay').fadeOut(900, function(){$('#Choco_overlay').remove()});
			$('#Choco_content').fadeOut(500, function(){$('#Choco_content').remove()});
			settings.imageActuelle = 0;
		}
		
};
})(jQuery);